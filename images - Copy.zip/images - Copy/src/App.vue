<template>
  <div>
    <AppHeader></AppHeader>
  </div>
</template>
<script>
import AppHeader from "./components/AppHeader";

export default {
  name: "App",
  components: {
    AppHeader
  }
};
</script>